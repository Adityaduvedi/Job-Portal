# Job Portal Web Application
A full-stack job portal using HTML, CSS, JavaScript, PHP (OOP), MySQL, Git, and background job processing with cron.

## Features
- Post jobs using a web form
- Display job listings dynamically
- Store data in MySQL database
- Object-oriented PHP backend
- Daily cleanup of old jobs using a background job

## Setup Instructions
1. Import the \`sql/schema.sql\` into MySQL.
2. Update DB credentials in \`php/db.php\`
3. Run the project using XAMPP/WAMP
4. Schedule cron for cleanup:
\`\`\`
0 0 * * * php /path/to/project/php/clean_expired_jobs.php
\`\`\`

## Folder Structure
job-portal/
├── css/style.css
├── js/script.js
├── php/
├── sql/schema.sql
├── index.html
└── README.md

## License
MIT